# DataBase-Frontend-Project

This project was made using PHP in order to access the database that was created in MySQL. We hosted the database on PHPmyadmin and were able to manipulate it using PHP.


#Steps in order to make it run

1. Find the 'movies.sql' and import it into your phpmyadmin database.

2. Import the table 'movies_tvshow' and the data that goes into the table.

3. In the php file 'database-conn' make sure that the connection name matches your database name in order to access the data inside.
